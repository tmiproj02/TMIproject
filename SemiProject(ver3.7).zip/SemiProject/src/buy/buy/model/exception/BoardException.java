package buy.buy.model.exception;

public class BoardException extends Exception {
	
	public BoardException() {}
	
	public BoardException(String msg) {
		super(msg);
	}
}
