package charge.model.exception;

public class CashRechargeException extends Exception{

	public CashRechargeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CashRechargeException(String msg) {
		super(msg);
	}
	
}
