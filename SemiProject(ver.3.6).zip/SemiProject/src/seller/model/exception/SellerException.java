package seller.model.exception;

public class SellerException extends Exception{
	public SellerException() {
		super();
	}
	
	
	public SellerException(String msg) {
		super(msg);
		
	}
}
