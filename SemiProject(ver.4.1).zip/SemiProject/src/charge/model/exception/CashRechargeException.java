package charge.model.exception;

public class CashRechargeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CashRechargeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CashRechargeException(String msg) {
		super(msg);
	}
	
}
